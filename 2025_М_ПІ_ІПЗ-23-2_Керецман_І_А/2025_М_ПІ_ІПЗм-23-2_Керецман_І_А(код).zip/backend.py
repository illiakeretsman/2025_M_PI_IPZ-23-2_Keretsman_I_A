from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict
import pickle
import os
import json
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score
import uvicorn
from contextlib import asynccontextmanager
from langdetect import detect
from langdetect.lang_detect_exception import LangDetectException
from googletrans import Translator
import asyncio

models = {}
vectorizer = None
training_results = {}
is_loaded = False
translator = None

MODELS_DIR = "saved_models"
VECTORIZER_PATH = os.path.join(MODELS_DIR, "vectorizer.pkl")
RESULTS_PATH = os.path.join(MODELS_DIR, "training_results.json")

def load_models():
    global models, vectorizer, training_results, is_loaded, translator
    
    try:
        translator = Translator()
        
        if not os.path.exists(VECTORIZER_PATH) or not os.path.exists(RESULTS_PATH):
            print("❌ Model files not found")
            return False
        
        with open(VECTORIZER_PATH, 'rb') as f:
            vectorizer = pickle.load(f)
        
        with open(RESULTS_PATH, 'r', encoding='utf-8') as f:
            training_results = json.load(f)
        
        model_files = {
            "Naive Bayes": "naive_bayes.pkl",
            "SVM": "svm.pkl", 
            "Logistic Regression": "logistic_regression.pkl",
            "Gradient Boosting": "custom_stacking.pkl"
        }
        
        models = {}
        for model_name, filename in model_files.items():
            model_path = os.path.join(MODELS_DIR, filename)
            if os.path.exists(model_path):
                with open(model_path, 'rb') as f:
                    models[model_name] = pickle.load(f)
            else:
                print(f"❌ Model not found: {model_name}")
        
        if len(models) > 0:
            is_loaded = True
            print(f"✅ Loaded {len(models)} models")
            return True
        else:
            print("❌ Failed to load any models")
            return False
            
    except Exception as e:
        print(f"❌ Error loading models: {e}")
        return False

@asynccontextmanager
async def lifespan(app: FastAPI):
    load_models()
    yield

app = FastAPI(title="Toxicity Classifier API", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class TextRequest(BaseModel):
    text: str

class ModelInfo(BaseModel):
    model_config = ConfigDict(protected_namespaces=())
    
    name: str
    accuracy: float
    precision: float
    recall: float
    f1: float
    training_time: float

class PredictionResult(BaseModel):
    model_config = ConfigDict(protected_namespaces=())
    
    model_name: str
    prediction: str
    probability: float
    is_toxic: bool

class AnalysisResponse(BaseModel):
    original_text: str
    detected_language: str
    translated_text: str
    translation_used: bool
    results: list[PredictionResult]

def calculate_topsis(metrics_data):
    weights = {
        'accuracy': 0.3,   
        'precision': 0.15, 
        'recall': 0.4,     
        'f1': 0.15         
    }
    
    models_list = list(metrics_data.keys())
    criteria = ['accuracy', 'precision', 'recall', 'f1']
    
    decision_matrix = []
    for model in models_list:
        row = [
            metrics_data[model]['accuracy'],
            metrics_data[model]['precision'],
            metrics_data[model]['recall'],
            metrics_data[model]['f1']
        ]
        decision_matrix.append(row)
    
    decision_matrix = np.array(decision_matrix)
    
    normalized_matrix = np.zeros_like(decision_matrix)
    for j, criterion in enumerate(criteria):
        column_sum_squares = np.sum(decision_matrix[:, j] ** 2)
        for i in range(len(models_list)):
            normalized_matrix[i, j] = decision_matrix[i, j] / np.sqrt(column_sum_squares)
    
    ideal_solution = np.zeros(len(criteria))
    anti_ideal_solution = np.zeros(len(criteria))
    
    for j, criterion in enumerate(criteria):
        ideal_solution[j] = np.max(normalized_matrix[:, j])
        anti_ideal_solution[j] = np.min(normalized_matrix[:, j])
    
    results = []
    for i, model in enumerate(models_list):
        d_plus = 0
        for j, criterion in enumerate(criteria):
            weight = weights[criterion]
            diff_plus = normalized_matrix[i, j] - ideal_solution[j]
            d_plus += weight * (diff_plus ** 2)
        d_plus = np.sqrt(d_plus)
        
        d_minus = 0
        for j, criterion in enumerate(criteria):
            weight = weights[criterion]
            diff_minus = normalized_matrix[i, j] - anti_ideal_solution[j]
            d_minus += weight * (diff_minus ** 2)
        if d_plus + d_minus == 0:
            ci = 0
        else:
            ci = d_minus / (d_plus + d_minus)
        
        results.append({
            'model': model,
            'efficiency_index': ci,
            'metrics': metrics_data[model]
        })
    
    results.sort(key=lambda x: x['efficiency_index'], reverse=True)
    return results

@app.get("/")
async def root():
    return {"message": "Toxicity Classifier API", "status": "running", "models_loaded": is_loaded}

@app.get("/models/info")
async def get_models_info():
    if not is_loaded:
        raise HTTPException(status_code=503, detail="Models not loaded")
    
    models_info = []
    for model_name, metrics in training_results.items():
        models_info.append(ModelInfo(
            name=model_name,
            accuracy=metrics['accuracy'],
            precision=metrics['precision'],
            recall=metrics['recall'],
            f1=metrics['f1'],
            training_time=metrics['training_time']
        ))
    
    topsis_results = calculate_topsis(training_results)
    
    return {
        "models": models_info,
        "topsis_ranking": topsis_results,
        "best_model": topsis_results[0]['model'] if topsis_results else None
    }

@app.post("/analyze", response_model=AnalysisResponse)
async def analyze_text(request: TextRequest):
    if not is_loaded:
        raise HTTPException(status_code=503, detail="Models not loaded")
    
    if not request.text.strip():
        raise HTTPException(status_code=400, detail="Text cannot be empty")
    
    try:
        original_text = request.text.strip()
        
        detected_lang = detect_language(original_text)
        text_for_analysis, translation_used = translate_text(original_text, 'en')
        
        text_vec = vectorizer.transform([text_for_analysis])
        
        results = []
        for model_name, model in models.items():
            prediction = model.predict(text_vec)[0]
            is_toxic = bool(prediction == 1)
            
            try:
                probabilities = model.predict_proba(text_vec)[0]
                prob_toxic = float(probabilities[1])
            except:
                prob_toxic = 1.0 if is_toxic else 0.0
            
            results.append(PredictionResult(
                model_name=model_name,
                prediction="TOXIC" if is_toxic else "NOT TOXIC",
                probability=prob_toxic,
                is_toxic=is_toxic
            ))
        
        return AnalysisResponse(
            original_text=original_text,
            detected_language=get_language_name(detected_lang),
            translated_text=text_for_analysis if translation_used else "",
            translation_used=translation_used,
            results=results
        )
        
    except Exception as e:
        print(f"❌ Analysis error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Analysis error: {str(e)}")

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "models_loaded": is_loaded,
        "models_count": len(models),
        "vectorizer_loaded": vectorizer is not None,
        "translator_loaded": translator is not None,
        "multilingual_support": True
    }

def detect_language(text: str) -> str:
    try:
        detected_lang = detect(text)
        return detected_lang
    except LangDetectException:
        return 'en'

def translate_text(text: str, target_lang: str = 'en') -> tuple[str, bool]:
    try:
        detected_lang = detect_language(text)
        
        if detected_lang == target_lang:
            return text, False
        
        translation = translator.translate(text, dest=target_lang)
        return translation.text, True
        
    except Exception as e:
        print(f"❌ Translation error: {e}")
        return text, False

def get_language_name(lang_code: str) -> str:
    language_names = {
        'en': 'English',
        'ru': 'Russian',
        'uk': 'Ukrainian', 
        'es': 'Spanish',
        'fr': 'French',
        'de': 'German',
        'it': 'Italian',
        'pt': 'Portuguese',
        'pl': 'Polish',
        'cs': 'Czech',
        'sk': 'Slovak',
        'bg': 'Bulgarian',
        'hr': 'Croatian',
        'sr': 'Serbian',
        'sl': 'Slovenian',
        'hu': 'Hungarian',
        'ro': 'Romanian',
        'lt': 'Lithuanian',
        'lv': 'Latvian',
        'et': 'Estonian',
        'fi': 'Finnish',
        'sv': 'Swedish',
        'no': 'Norwegian',
        'da': 'Danish',
        'nl': 'Dutch',
        'zh': 'Chinese',
        'ja': 'Japanese',
        'ko': 'Korean',
        'ar': 'Arabic',
        'hi': 'Hindi',
        'tr': 'Turkish',
        'th': 'Thai',
        'vi': 'Vietnamese'
    }
    return language_names.get(lang_code, f'Unknown ({lang_code})')

if __name__ == "__main__":
    print("🚀 Starting Toxicity Classifier API...")
    uvicorn.run("backend:app", host="0.0.0.0", port=8000, reload=True) 