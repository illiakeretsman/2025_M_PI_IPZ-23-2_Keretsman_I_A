import numpy as np
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import cross_val_score, cross_val_predict, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import SVC
import warnings
warnings.filterwarnings('ignore')

class CustomStackingClassifier(BaseEstimator, ClassifierMixin):
    def __init__(self, alpha=1.0, C=1.0, max_iter=1000, meta_model=None, cv_folds=5, random_state=42):
        self.alpha = alpha
        self.C = C
        self.max_iter = max_iter
        self.cv_folds = cv_folds
        self.random_state = random_state
        
        self.nb = MultinomialNB(alpha=alpha)
        self.lr = LogisticRegression(max_iter=max_iter, random_state=random_state, solver='liblinear')
        self.svm = SVC(kernel='linear', C=C, probability=True, max_iter=max_iter, random_state=random_state)
        
        self.meta_model = meta_model if meta_model else GradientBoostingClassifier(
            n_estimators=150, 
            learning_rate=0.1,
            max_depth=3,
            random_state=random_state
        )
        
        self.scaler = StandardScaler()
        
    def fit(self, X, y):
        print("Навчання базових методів...")
        self.nb.fit(X, y)
        self.lr.fit(X, y)
        self.svm.fit(X, y)
        
        print("Генерація передбачень через кросс-валідацію...")
        cv = StratifiedKFold(n_splits=self.cv_folds, shuffle=True, random_state=self.random_state)
        
        nb_preds = cross_val_predict(self.nb, X, y, cv=cv, method='predict_proba')
        lr_preds = cross_val_predict(self.lr, X, y, cv=cv, method='predict_proba')
        svm_preds = cross_val_predict(self.svm, X, y, cv=cv, method='predict_proba')
        
        stacked_features = np.hstack((nb_preds, lr_preds, svm_preds))
        stacked_features_scaled = self.scaler.fit_transform(stacked_features)
        
        print("Навчання мета-моделі...")
        self.meta_model.fit(stacked_features_scaled, y)
        return self
    
    def predict(self, X):
        nb_preds = self.nb.predict_proba(X)
        lr_preds = self.lr.predict_proba(X)
        svm_preds = self.svm.predict_proba(X)
        
        stacked_features = np.hstack((nb_preds, lr_preds, svm_preds))
        stacked_features_scaled = self.scaler.transform(stacked_features)
        
        return self.meta_model.predict(stacked_features_scaled)
    
    def predict_proba(self, X):
        nb_preds = self.nb.predict_proba(X)
        lr_preds = self.lr.predict_proba(X)
        svm_preds = self.svm.predict_proba(X)
        stacked_features = np.hstack((nb_preds, lr_preds, svm_preds))
        stacked_features_scaled = self.scaler.transform(stacked_features)
        return self.meta_model.predict_proba(stacked_features_scaled)
