import { useState } from 'react'
import ModelsInfo from './components/ModelsInfo'
import TextAnalyzer from './components/TextAnalyzer'

function App() {
  const [activeTab, setActiveTab] = useState('models')

  return (
    <div className="min-h-screen bg-gray-950">
      <div className="relative">
        <header className="border-b border-gray-800 bg-gray-950/80 backdrop-blur-sm sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                  <span className="text-gray-900 text-sm">🛡️</span>
                </div>
                <div>
                  <h1 className="text-xl font-semibold text-white">
                    Toxicity Analyzer
                  </h1>
                  <p className="text-sm text-gray-400">
                    AI Content Moderation
                  </p>
                </div>
              </div>
            </div>
          </div>
        </header>

        <nav className="border-b border-gray-800 bg-gray-950">
          <div className="max-w-7xl mx-auto px-6">
            <div className="flex space-x-8">
              <button
                onClick={() => setActiveTab('models')}
                className={`relative py-4 px-1 text-sm font-medium transition-colors duration-200 ${
                  activeTab === 'models'
                    ? 'text-white border-b-2 border-white'
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                Model Performance
              </button>
              <button
                onClick={() => setActiveTab('analyzer')}
                className={`relative py-4 px-1 text-sm font-medium transition-colors duration-200 ${
                  activeTab === 'analyzer'
                    ? 'text-white border-b-2 border-white'
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                Text Analysis
              </button>
            </div>
          </div>
        </nav>

        <main className="relative">
          <div className="transition-all duration-200 ease-in-out">
            {activeTab === 'models' && (
              <div>
                <ModelsInfo />
              </div>
            )}
            {activeTab === 'analyzer' && (
              <div>
                <TextAnalyzer />
              </div>
            )}
          </div>
        </main>

        <footer className="border-t border-gray-800 bg-gray-900 mt-16">
          <div className="max-w-7xl mx-auto px-6 py-8">
            <div className="text-center">
              <p className="text-sm text-gray-400 mb-4">
                Powered by advanced machine learning models
              </p>
              <div className="flex justify-center space-x-6">
                <span className="inline-flex items-center text-xs text-gray-500">
                  <span className="mr-1">🤖</span>
                  AI-Powered
                </span>
                <span className="inline-flex items-center text-xs text-gray-500">
                  <span className="mr-1">⚡</span>
                  Real-time
                </span>
                <span className="inline-flex items-center text-xs text-gray-500">
                  <span className="mr-1">🎯</span>
                  TOPSIS Analysis
                </span>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  )
}

export default App
