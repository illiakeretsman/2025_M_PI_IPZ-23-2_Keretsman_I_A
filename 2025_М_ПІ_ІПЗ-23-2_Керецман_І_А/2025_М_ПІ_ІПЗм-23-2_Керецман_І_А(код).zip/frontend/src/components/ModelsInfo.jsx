import { useState, useEffect } from 'react'

const ModelsInfo = () => {
  const [modelsData, setModelsData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchModelsInfo()
  }, [])

  const fetchModelsInfo = async () => {
    try {
      setLoading(true)
      const response = await fetch('http://localhost:8000/models/info')
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      const data = await response.json()
      setModelsData(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const formatMetric = (value) => {
    return (value * 100).toFixed(2) + '%'
  }

  const formatTime = (seconds) => {
    return seconds.toFixed(2) + 's'
  }

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-8 h-8 border-2 border-gray-600 border-t-white rounded-full animate-spin mb-4"></div>
          <p className="text-sm text-gray-400">Loading model data...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="max-w-md mx-auto">
          <div className="bg-red-950 border border-red-800 rounded-xl p-6">
            <div className="text-center">
              <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-900 mb-4">
                <span className="text-red-400 text-xl">⚠️</span>
              </div>
              <h3 className="text-lg font-semibold text-red-300 mb-2">Connection Error</h3>
              <p className="text-sm text-red-400 mb-2">{error}</p>
              <p className="text-xs text-red-500 mb-6">
                Make sure the backend server is running on port 8000
              </p>
              <button
                onClick={fetchModelsInfo}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-medium py-2.5 px-4 rounded-lg transition-all duration-200"
              >
                Try Again
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      
      {modelsData?.best_model && (
        <div className="mb-8">
          <div className="bg-gradient-to-r from-gray-900 to-gray-800 border border-gray-700 rounded-xl p-6 text-center shadow-lg">
            <div className="inline-flex items-center space-x-4">
              <div className="text-3xl">🏆</div>
              <div>
                <h2 className="text-xl font-semibold text-white mb-1">
                  Best Performing Model
                </h2>
                <p className="text-lg font-medium text-gray-300">
                  {modelsData.best_model}
                </p>
                <p className="text-sm text-gray-400 mt-1">Ranked #1 by TOPSIS Analysis</p>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden shadow-lg mb-8">
        <div className="bg-gray-800 px-6 py-4 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-1">
            Model Performance Comparison
          </h3>
          <p className="text-sm text-gray-400">Detailed metrics for all trained models</p>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-700">
            <thead className="bg-gray-800">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Model
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Accuracy
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Precision
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Recall
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-300 uppercase tracking-wider">
                  F1-Score
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Training Time
                </th>
              </tr>
            </thead>
            <tbody className="bg-gray-900 divide-y divide-gray-800">
              {modelsData?.models?.map((model) => (
                <tr key={model.name} className="hover:bg-gray-800 transition-colors duration-150">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-white rounded-full mr-3"></div>
                      <span className="text-sm font-medium text-white">{model.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className="text-sm text-white font-medium">{formatMetric(model.accuracy)}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className="text-sm text-gray-300">{formatMetric(model.precision)}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className="text-sm text-gray-300">{formatMetric(model.recall)}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className="text-sm text-gray-300">{formatMetric(model.f1)}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className="text-sm text-gray-400">{formatTime(model.training_time)}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modelsData?.topsis_ranking && (
        <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden shadow-lg mb-8">
          <div className="bg-gray-800 px-6 py-4 border-b border-gray-700">
            <h3 className="text-lg font-semibold text-white mb-1">
              TOPSIS Model Ranking
            </h3>
            <p className="text-sm text-gray-400">
              Multi-criteria analysis with weights: Accuracy (30%), Precision (15%), Recall (40%), F1-score (15%)
            </p>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {modelsData.topsis_ranking.map((item, index) => (
                <div
                  key={item.model}
                  className="bg-gray-800 border border-gray-700 rounded-lg p-4 hover:shadow-md transition-all duration-200"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="text-2xl mr-4">
                        {index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`}
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold text-white mb-1">{item.model}</h4>
                        <p className="text-sm text-gray-400">
                          Efficiency Index: <span className="font-medium text-white">{(item.efficiency_index * 100).toFixed(2)}%</span>
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="w-32 bg-gray-700 rounded-full h-2 mb-2 overflow-hidden">
                        <div
                          className="h-2 rounded-full bg-white transition-all duration-1000"
                          style={{ width: `${item.efficiency_index * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-xs text-gray-400">Performance Score</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="text-center">
        <button
          onClick={fetchModelsInfo}
          className="bg-white hover:bg-gray-100 text-gray-900 font-medium py-2.5 px-6 rounded-lg transition-all duration-200 inline-flex items-center"
        >
          <span className="mr-2">🔄</span>
          Refresh Data
        </button>
      </div>
    </div>
  )
}

export default ModelsInfo 