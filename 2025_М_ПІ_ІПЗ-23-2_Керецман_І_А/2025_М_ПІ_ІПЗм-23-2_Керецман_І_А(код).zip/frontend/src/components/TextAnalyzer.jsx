import { useState } from 'react'

const TextAnalyzer = () => {
  const [text, setText] = useState('')
  const [results, setResults] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const analyzeText = async () => {
    if (!text.trim()) {
      setError('Please enter text to analyze')
      return
    }

    try {
      setLoading(true)
      setError(null)
      
      const response = await fetch('http://localhost:8000/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: text.trim() }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()
      setResults(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const clearResults = () => {
    setText('')
    setResults(null)
    setError(null)
  }

  const formatProbability = (prob) => {
    return (prob * 100).toFixed(1) + '%'
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        
        <div className="lg:col-span-1">
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 shadow-lg">
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-white mb-2">
                Text Analysis
              </h3>
              <p className="text-sm text-gray-400">
                Enter text to analyze for toxicity
              </p>
            </div>
            
            <textarea
              id="text-input"
              rows={8}
              className="w-full px-3 py-3 bg-gray-800 border border-gray-700 rounded-lg text-sm resize-none text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-white focus:border-transparent transition-all duration-200"
              placeholder="Type your message here..."
              value={text}
              onChange={(e) => setText(e.target.value)}
            />
            
            <div className="flex gap-3 mt-4">
              <button
                onClick={analyzeText}
                disabled={loading || !text.trim()}
                className="flex-1 bg-white text-gray-900 disabled:bg-gray-700 disabled:text-gray-500 px-4 py-2.5 rounded-lg text-sm font-medium flex items-center justify-center transition-all duration-200 hover:bg-gray-100 disabled:hover:bg-gray-700"
              >
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-gray-900 border-t-transparent mr-2"></div>
                    Analyzing...
                  </>
                ) : (
                  'Analyze Text'
                )}
              </button>
              <button
                onClick={clearResults}
                className="bg-gray-800 hover:bg-gray-700 text-gray-300 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 border border-gray-700"
              >
                Clear
              </button>
            </div>
            
            {error && (
              <div className="mt-4 bg-red-950 border border-red-800 rounded-lg p-4">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <span className="text-red-400 text-sm">⚠️</span>
                  </div>
                  <div className="ml-3">
                    <h4 className="text-sm font-medium text-red-300">Error</h4>
                    <p className="text-sm text-red-400 mt-1">{error}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="lg:col-span-2">
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 shadow-lg">
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-white mb-2">
                Quick Examples
              </h3>
              <p className="text-sm text-gray-400">
                Click on any example to test the analyzer
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-sm font-medium text-white mb-3 flex items-center">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                  Safe Examples (Multilingual)
                </h4>
                <div className="space-y-2">
                  {[
                    { text: "Great article, thanks for sharing!", lang: "🇺🇸 English" },
                    { text: "Excellent article, merci pour le partage!", lang: "🇫🇷 French" },
                    { text: "Чудова стаття, дякую за інформацію!", lang: "🇺🇦 Ukrainian" },
                    { text: "Excelente artículo, gracias por compartir!", lang: "🇪🇸 Spanish" }
                  ].map((example, index) => (
                    <button
                      key={index}
                      onClick={() => setText(example.text)}
                      className="text-left w-full p-3 text-sm bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 text-gray-300 transition-all duration-200 hover:shadow-md"
                    >
                      <div className="font-medium text-white mb-1 flex items-center justify-between">
                        <span>Example {index + 1}</span>
                        <span className="text-xs text-gray-500">{example.lang}</span>
                      </div>
                      <div className="text-gray-400">"{example.text}"</div>
                    </button>
                  ))}
                </div>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-white mb-3 flex items-center">
                  <span className="w-2 h-2 bg-red-500 rounded-full mr-2"></span>
                  Toxic Examples (Multilingual)
                </h4>
                <div className="space-y-2">
                  {[
                    { text: "You're such an idiot, you don't understand", lang: "🇺🇸 English" },
                    { text: "Tu es tellement stupide, tu ne comprends rien", lang: "🇫🇷 French" },
                    { text: "Ти такий дурень, нічого не розумієш", lang: "🇺🇦 Ukrainian" },
                    { text: "Eres tan idiota, no entiendes nada", lang: "🇪🇸 Spanish" }
                  ].map((example, index) => (
                    <button
                      key={index}
                      onClick={() => setText(example.text)}
                      className="text-left w-full p-3 text-sm bg-gray-800 hover:bg-gray-700 rounded-lg border border-gray-700 text-gray-300 transition-all duration-200 hover:shadow-md"
                    >
                      <div className="font-medium text-white mb-1 flex items-center justify-between">
                        <span>Example {index + 1}</span>
                        <span className="text-xs text-gray-500">{example.lang}</span>
                      </div>
                      <div className="text-gray-400">"{example.text}"</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {results && (
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 shadow-lg">
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-white mb-2">
              Analysis Results
            </h3>
            
            {/* Language and Translation Info */}
            <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 mb-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-400 mb-1">Original Text:</p>
                  <p className="text-sm text-white">"{results.original_text}"</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400 mb-1">Detected Language:</p>
                  <p className="text-sm text-white flex items-center">
                    🌍 {results.detected_language}
                  </p>
                </div>
              </div>
              
              {results.translation_used && (
                <div className="mt-4 pt-4 border-t border-gray-700">
                  <p className="text-sm text-gray-400 mb-1">Translated for Analysis:</p>
                  <p className="text-sm text-blue-300">"{results.translated_text}"</p>
                  <p className="text-xs text-gray-500 mt-1">
                    🔄 Text was automatically translated to English for toxicity analysis
                  </p>
                </div>
              )}
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {results.results.map((result) => (
              <div
                key={result.model_name}
                className="bg-gray-800 border border-gray-700 rounded-lg p-4 hover:shadow-md transition-all duration-200"
              >
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium text-sm text-white">
                    {result.model_name}
                  </h4>
                  <div className="text-lg">
                    {result.is_toxic ? '⚠️' : '✅'}
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-400">Status</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      result.is_toxic 
                        ? 'bg-red-950 text-red-300 border border-red-800' 
                        : 'bg-green-950 text-green-300 border border-green-800'
                    }`}>
                      {result.is_toxic ? 'Toxic' : 'Safe'}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-400">Toxicity Probability</span>
                    <span className="text-sm font-medium text-white">
                      {formatProbability(result.probability)}
                    </span>
                  </div>

                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all duration-1000 ${
                        result.is_toxic ? 'bg-red-500' : 'bg-green-500'
                      }`}
                      style={{ width: `${result.probability * 100}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-3 gap-4 pt-6 border-t border-gray-800">
            <div className="text-center">
              <div className="text-2xl font-semibold text-white">
                {results.results.filter(r => r.is_toxic).length}
              </div>
              <div className="text-sm text-gray-400">Toxic Predictions</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-semibold text-white">
                {results.results.filter(r => !r.is_toxic).length}
              </div>
              <div className="text-sm text-gray-400">Safe Predictions</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-semibold text-white">
                {formatProbability(
                  results.results.reduce((sum, r) => sum + r.probability, 0) / results.results.length
                )}
              </div>
              <div className="text-sm text-gray-400">Average Probability</div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default TextAnalyzer 