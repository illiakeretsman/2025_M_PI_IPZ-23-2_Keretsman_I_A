import time
import pandas as pd
import pickle
import json
import os
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score
from sklearn.model_selection import train_test_split
from custom import CustomStackingClassifier

def calculate_topsis(metrics_data):
    weights = {
        'accuracy': 0.3,
        'precision': 0.15,
        'recall': 0.4,
        'f1': 0.15
    }
    
    models_list = list(metrics_data.keys())
    criteria = ['accuracy', 'precision', 'recall', 'f1']
    
    decision_matrix = []
    for model in models_list:
        row = [
            metrics_data[model]['accuracy'],
            metrics_data[model]['precision'],
            metrics_data[model]['recall'],
            metrics_data[model]['f1']
        ]
        decision_matrix.append(row)
    
    decision_matrix = np.array(decision_matrix)
    
    normalized_matrix = np.zeros_like(decision_matrix)
    for j, criterion in enumerate(criteria):
        column_sum_squares = np.sum(decision_matrix[:, j] ** 2)
        for i in range(len(models_list)):
            normalized_matrix[i, j] = decision_matrix[i, j] / np.sqrt(column_sum_squares)
    
    ideal_solution = np.zeros(len(criteria))
    anti_ideal_solution = np.zeros(len(criteria))
    
    for j, criterion in enumerate(criteria):
        ideal_solution[j] = np.max(normalized_matrix[:, j])
        anti_ideal_solution[j] = np.min(normalized_matrix[:, j])
    
    results = []
    for i, model in enumerate(models_list):
        d_plus = 0
        for j, criterion in enumerate(criteria):
            weight = weights[criterion]
            diff_plus = normalized_matrix[i, j] - ideal_solution[j]
            d_plus += weight * (diff_plus ** 2)
        d_plus = np.sqrt(d_plus)
        
        d_minus = 0
        for j, criterion in enumerate(criteria):
            weight = weights[criterion]
            diff_minus = normalized_matrix[i, j] - anti_ideal_solution[j]
            d_minus += weight * (diff_minus ** 2)
        d_minus = np.sqrt(d_minus)
        
        if d_plus + d_minus == 0:
            ci = 0
        else:
            ci = d_minus / (d_plus + d_minus)
        
        results.append({
            'model': model,
            'efficiency_index': ci,
            'rank': 0
        })
    
    results.sort(key=lambda x: x['efficiency_index'], reverse=True)
    
    for i, result in enumerate(results):
        result['rank'] = i + 1
    
    return results

def save_models_and_results(models, vectorizer, training_results):
    models_dir = "saved_models"
    
    if not os.path.exists(models_dir):
        os.makedirs(models_dir)
    
    try:
        print("Saving models and results...")
        
        vectorizer_path = os.path.join(models_dir, "vectorizer.pkl")
        with open(vectorizer_path, 'wb') as f:
            pickle.dump(vectorizer, f)
        
        for model_name, model in models.items():
            model_filename = model_name.replace(' ', '_').lower() + '.pkl'
            model_path = os.path.join(models_dir, model_filename)
            with open(model_path, 'wb') as f:
                pickle.dump(model, f)
        
        results_path = os.path.join(models_dir, "training_results.json")
        with open(results_path, 'w', encoding='utf-8') as f:
            json.dump(training_results, f, ensure_ascii=False, indent=2)
        
        print("All data saved successfully!")
        return True
        
    except Exception as e:
        print(f"Error saving: {e}")
        return False

def main():
    print("Training and comparing toxicity models")
    print("=" * 50)
    
    print("Loading data...")
    train = pd.read_csv("train.csv")
    test = pd.read_csv("test.csv")
    print(f"Loaded {len(train)} training and {len(test)} test records")
    
    print("Preparing data...")
    X_train = train['comment_text']
    y_train = train['toxic']
    
    X_train_full, X_val, y_train_full, y_val = train_test_split(
        X_train, y_train, test_size=0.1, random_state=42, stratify=y_train
    )
    
    print(f"Training set: {len(X_train_full)} records")
    print(f"Validation set: {len(X_val)} records")
    
    print("TF-IDF vectorization...")
    vectorizer = TfidfVectorizer(
        max_features=10000,
        stop_words='english',
        ngram_range=(1, 2),
        min_df=2,
        max_df=0.95
    )
    
    X_train_vec = vectorizer.fit_transform(X_train_full)
    X_val_vec = vectorizer.transform(X_val)
    print(f"Vector size: {X_train_vec.shape}")
    
    models = {
        "Naive Bayes": MultinomialNB(alpha=0.1),
        "SVM": SVC(kernel='linear', C=0.1, max_iter=1000, random_state=42, probability=True),
        "Logistic Regression": LogisticRegression(
            max_iter=1000, 
            C=1.0, 
            solver='liblinear', 
            random_state=42
        ),
        "Gradient Boosting": CustomStackingClassifier(
            alpha=0.1,
            C=0.1,
            max_iter=1000,
            cv_folds=5,
            random_state=42
        )
    }
    
    results = {}
    trained_models = {}
    
    for model_name, model in models.items():
        print(f"\nTraining {model_name}...")
        
        start_time = time.time()
        model.fit(X_train_vec, y_train_full)
        training_time = time.time() - start_time
        
        preds = model.predict(X_val_vec)
        
        accuracy = accuracy_score(y_val, preds)
        precision = precision_score(y_val, preds, average='weighted', zero_division=0)
        recall = recall_score(y_val, preds, average='weighted', zero_division=0)
        f1 = f1_score(y_val, preds, average='weighted', zero_division=0)
        
        results[model_name] = {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'training_time': training_time
        }
        
        trained_models[model_name] = model
        
        print(f"{model_name} Results:")
        print(f"  Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
        print(f"  Precision: {precision:.4f} ({precision*100:.2f}%)")
        print(f"  Recall: {recall:.4f} ({recall*100:.2f}%)")
        print(f"  F1-Score: {f1:.4f} ({f1*100:.2f}%)")
        print(f"  Training time: {training_time:.2f}s")
    
    print(f"\n{'='*50}")
    print("TOPSIS ANALYSIS")
    print(f"{'='*50}")
    
    topsis_results = calculate_topsis(results)
    
    print("Criteria weights:")
    print("  • Accuracy: 30%")
    print("  • Precision: 15%")
    print("  • Recall: 40%")
    print("  • F1-Score: 15%")
    print()
    
    print("TOPSIS Ranking:")
    for result in topsis_results:
        model_name = result['model']
        rank = result['rank']
        efficiency = result['efficiency_index']
        
        medal = "1st" if rank == 1 else "2nd" if rank == 2 else "3rd" if rank == 3 else f"{rank}th"
        
        print(f"{medal} {model_name}")
        print(f"    Efficiency index: {efficiency:.4f} ({efficiency*100:.2f}%)")
        
        if rank == 1:
            metrics = results[model_name]
            print(f"    Best model metrics:")
            print(f"      • Accuracy: {metrics['accuracy']:.4f}")
            print(f"      • Precision: {metrics['precision']:.4f}")
            print(f"      • Recall: {metrics['recall']:.4f}")
            print(f"      • F1-Score: {metrics['f1']:.4f}")
            print(f"      • Time: {metrics['training_time']:.2f}s")
        print()
    
    print(f"\n{'='*50}")
    print("FINAL COMPARISON")
    print(f"{'='*50}")
    
    print(f"{'Model':<20} | {'Accuracy':<8} | {'Precision':<9} | {'Recall':<8} | {'F1-Score':<8} | {'Time':<8}")
    print("-" * 80)
    
    sorted_results = sorted(results.items(), key=lambda x: x[1]['accuracy'], reverse=True)
    
    for model_name, metrics in sorted_results:
        print(f"{model_name:<20} | {metrics['accuracy']:<8.4f} | {metrics['precision']:<9.4f} | "
              f"{metrics['recall']:<8.4f} | {metrics['f1']:<8.4f} | {metrics['training_time']:<8.2f}")
    
    save_success = save_models_and_results(trained_models, vectorizer, results)
    
    if save_success:
        print("\nTRAINING COMPLETED SUCCESSFULLY!")
        print("All models trained and saved")
        print("Results saved to JSON")
        print("Vectorizer saved")
    else:
        print("\nTraining completed but there were saving issues")

if __name__ == "__main__":
    main()
